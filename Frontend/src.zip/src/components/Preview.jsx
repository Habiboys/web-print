import { useState } from "react";
import { Document, Page } from "react-pdf";
import PropTypes from "prop-types";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";

// Worker PDF.js langsung diintegrasikan tanpa perlu setting manual
const Preview = ({ fileUrl }) => {
  const [numPages, setNumPages] = useState(null);
  const [pageNumber, setPageNumber] = useState(1);

  const onDocumentLoadSuccess = ({ numPages }) => {
    setNumPages(numPages);
  };

  return (
    <div className="my-4">
      <h3 className="text-xl font-semibold mb-2">Preview</h3>
      <div className="border rounded p-4">
        <Document
          file={fileUrl}
          onLoadSuccess={onDocumentLoadSuccess}
          error={<div>Error loading PDF!</div>}
          loading={<div>Loading PDF...</div>}
        >
          <Page pageNumber={pageNumber} width={600} />
        </Document>
        {numPages && (
          <p className="text-center mt-2">
            Page {pageNumber} of {numPages}
          </p>
        )}
        {numPages > 1 && (
          <div className="flex justify-center gap-2 mt-2">
            <button
              onClick={() => setPageNumber((page) => Math.max(page - 1, 1))}
              disabled={pageNumber <= 1}
              className="px-4 py-2 bg-gray-200 rounded disabled:opacity-50"
            >
              Previous
            </button>
            <button
              onClick={() => setPageNumber((page) => Math.min(page + 1, numPages))}
              disabled={pageNumber >= numPages}
              className="px-4 py-2 bg-gray-200 rounded disabled:opacity-50"
            >
              Next
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

Preview.propTypes = {
  fileUrl: PropTypes.string.isRequired,
};

export default Preview;
