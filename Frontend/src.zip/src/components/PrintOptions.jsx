import { useState, useEffect } from "react";
import PropTypes from 'prop-types';

const PrintOptions = ({ onOptionsSelected, isLoading = false, initialOptions = null }) => {
  const [options, setOptions] = useState({
    pages: "all",
    copies: 1,
  });

  useEffect(() => {
    if (initialOptions) {
      setOptions(initialOptions);
    }
  }, [initialOptions]);

  const handleChange = (name, value) => {
    setOptions(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onOptionsSelected(options);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4 border rounded-lg">


      {/* Pages Option */}
      <div className="space-y-1">
        <label htmlFor="pages" className="block">Pages:</label>
        <input
          type="text"
          id="pages"
          value={options.pages}
          onChange={(e) => handleChange('pages', e.target.value)}
          placeholder="e.g., 1-5, 8, 11-13 or 'all'"
          className="w-full px-3 py-2 border rounded"
        />
      </div>

      {/* Copies Option */}
      <div className="space-y-1">
        <label htmlFor="copies" className="block">Copies:</label>
        <input
          type="number"
          id="copies"
          min="1"
          max="99"
          value={options.copies}
          onChange={(e) => handleChange('copies', parseInt(e.target.value))}
          className="w-full px-3 py-2 border rounded"
        />
      </div>


      {/* Submit Button */}
      <button
        type="submit"
        disabled={isLoading}
        className={`
          w-full px-4 py-2 rounded
          ${isLoading 
            ? 'bg-gray-400 cursor-not-allowed' 
            : 'bg-blue-500 hover:bg-blue-600'}
          text-white font-medium transition-colors
        `}
      >
        {isLoading ? 'Printing...' : 'Print Document'}
      </button>
    </form>
  );
};

PrintOptions.propTypes = {
  onOptionsSelected: PropTypes.func.isRequired,
  isLoading: PropTypes.bool,
  initialOptions: PropTypes.shape({
    pages: PropTypes.string,
    copies: PropTypes.number,
  })
};

export default PrintOptions;
