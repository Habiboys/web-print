import { useState } from "react";
import axios from 'axios';

import FileUpload from "./components/FileUpload";
import Preview from "./components/Preview";
import PrintOptions from "./components/PrintOptions";

function App() {
  const [fileData, setFileData] = useState(null);
  const [printOptions, setPrintOptions] = useState({
    pages: "all",
    copies: 1,
  });
  const [isPrinting, setIsPrinting] = useState(false);

  const handleFileUploaded = (data) => {
    console.log('File uploaded:', data);  // Log data untuk memastikan file berhasil diupload
    setFileData(data);
  };

  const handleOptionsSelected = async (options) => {
    setPrintOptions(options);
    try {
      setIsPrinting(true);
      await handlePrint(fileData, options);
    } catch (error) {
      console.error('Print error:', error);
      alert('Failed to print. Please try again.');
    } finally {
      setIsPrinting(false);
    }
  };

  const handlePrint = async (file, options) => {
    try {
      const response = await axios.post(' https://47a0-103-212-43-219.ngrok-free.app/print', {
        fileUrl: file.url,  // Pastikan ini adalah URL yang dapat diakses oleh backend
        options: {
          pages: options.pages,
          copies: options.copies,
        }
      });
  
      const { jobId } = response.data;  // ID pekerjaan print yang dikembalikan dari backend
      
      const checkPrintStatus = setInterval(async () => {
        try {
          const statusResponse = await axios.get(`http://localhost:3000/print-status/${jobId}`);
          const { status, completed } = statusResponse.data;
          
          console.log(`Print status: ${status}`);
          
          if (completed) {
            clearInterval(checkPrintStatus);
            alert('Document printed successfully!');
          }
        } catch (error) {
          console.error('Error checking print status:', error);
          clearInterval(checkPrintStatus);
        }
      }, 2000);
    } catch (error) {
      console.error('Print error:', error);
      throw new Error('Failed to print document');
    }
  };
  
  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Web Print</h1>
      
      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Upload Document</h2>
        <FileUpload onFileUploaded={handleFileUploaded} />
      </section>

      {/* Preview Section */}
      {fileData && (
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Document Preview</h2>
          <Preview fileUrl={fileData.url} />
        </section>
      )}

      {/* Print Options Section */}
      {fileData && (
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Print Settings</h2>
          <PrintOptions 
            onOptionsSelected={handleOptionsSelected}
            isLoading={isPrinting}
            initialOptions={printOptions}
          />
        </section>
      )}

      {/* Current Settings Display */}
      {printOptions && (
        <section className="mt-4 p-4 bg-gray-50 rounded-lg">
          <h2 className="text-lg font-semibold mb-2">Current Print Settings</h2>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>Pages:</div>
            <div>{printOptions.pages}</div>
            <div>Copies:</div>
            <div>{printOptions.copies}</div>
          </div>
        </section>
      )}
    </div>
  );
}

export default App;
